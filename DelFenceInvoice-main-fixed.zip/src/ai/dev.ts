
import { config } from 'dotenv';
config();

import '@/ai/flows/order-email-draft.ts';
import '@/ai/flows/estimate-email-draft.ts';
import '@/ai/flows/invoice-email-draft.ts';
